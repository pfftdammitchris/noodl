export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
};

export type ActionObject = {
  __typename?: 'ActionObject';
  actionType?: Maybe<NoodlString>;
  properties?: Maybe<Array<Maybe<Property>>>;
};

export type ComponentObject = {
  __typename?: 'ComponentObject';
  properties?: Maybe<Array<Maybe<Property>>>;
};

export type DocumentObject = {
  __typename?: 'DocumentObject';
  atime?: Maybe<Scalars['Int']>;
  atimes?: Maybe<Scalars['Int']>;
  bsig?: Maybe<Scalars['String']>;
  ctime?: Maybe<Scalars['Int']>;
  deat?: Maybe<Scalars['String']>;
  eid?: Maybe<Scalars['String']>;
  esig?: Maybe<Scalars['String']>;
  fid?: Maybe<Scalars['String']>;
  id?: Maybe<Scalars['String']>;
  mtime?: Maybe<Scalars['Int']>;
  name?: Maybe<NameFieldObject>;
  size?: Maybe<Scalars['Int']>;
  subtype?: Maybe<Scalars['String']>;
  tage?: Maybe<Scalars['Int']>;
  type?: Maybe<Scalars['Int']>;
};

export type EdgeObject = {
  __typename?: 'EdgeObject';
  atime?: Maybe<Scalars['Int']>;
  atimes?: Maybe<Scalars['Int']>;
  besak?: Maybe<Scalars['String']>;
  bvid?: Maybe<Scalars['String']>;
  ctime?: Maybe<Scalars['Int']>;
  deat?: Maybe<Scalars['String']>;
  eesak?: Maybe<Scalars['String']>;
  etime?: Maybe<Scalars['Int']>;
  evid?: Maybe<Scalars['String']>;
  id?: Maybe<Scalars['String']>;
  mtime?: Maybe<Scalars['Int']>;
  name?: Maybe<NameFieldObject>;
  refid?: Maybe<Scalars['String']>;
  sig?: Maybe<Scalars['String']>;
  stime?: Maybe<Scalars['Int']>;
  subtype?: Maybe<Scalars['Int']>;
  tage?: Maybe<Scalars['Int']>;
  type?: Maybe<Scalars['Int']>;
};

export type IfObject = {
  __typename?: 'IfObject';
  if?: Maybe<Array<Maybe<Scalars['String']>>>;
};

export type NameFieldObject = {
  __typename?: 'NameFieldObject';
  data?: Maybe<Scalars['String']>;
  tags?: Maybe<Array<Maybe<Scalars['String']>>>;
  type?: Maybe<Scalars['String']>;
};

export type NoodlString = {
  __typename?: 'NoodlString';
  isReference?: Maybe<Scalars['Boolean']>;
  value?: Maybe<Scalars['String']>;
};

export type ObjectKey = {
  __typename?: 'ObjectKey';
  value?: Maybe<Scalars['String']>;
};

export type ObjectValue = {
  __typename?: 'ObjectValue';
  value?: Maybe<Scalars['String']>;
};

export type PageObject = {
  __typename?: 'PageObject';
  components?: Maybe<Array<Maybe<ComponentObject>>>;
  pageNumber?: Maybe<Scalars['Int']>;
};

export type Pair = {
  __typename?: 'Pair';
  key: Scalars['String'];
  value: Scalars['String'];
};

export type Property = {
  __typename?: 'Property';
  key: Scalars['String'];
  type?: Maybe<Scalars['String']>;
};

export type Query = {
  __typename?: 'Query';
  actionTypeObjects?: Maybe<Array<Maybe<ActionObject>>>;
  actionTypes?: Maybe<Array<Maybe<NoodlString>>>;
};

export type ReferenceProperty = {
  __typename?: 'ReferenceProperty';
  isRootReference?: Maybe<Scalars['Boolean']>;
};

export type VertexObject = {
  __typename?: 'VertexObject';
  atime?: Maybe<Scalars['Int']>;
  atimes?: Maybe<Scalars['Int']>;
  ctime?: Maybe<Scalars['Int']>;
  deat?: Maybe<Scalars['String']>;
  esk?: Maybe<Scalars['String']>;
  id?: Maybe<Scalars['String']>;
  mtime?: Maybe<Scalars['Int']>;
  name?: Maybe<NameFieldObject>;
  pk?: Maybe<Scalars['String']>;
  subtype?: Maybe<Scalars['String']>;
  tage?: Maybe<Scalars['Int']>;
  type?: Maybe<Scalars['Int']>;
  uid?: Maybe<Scalars['String']>;
};
