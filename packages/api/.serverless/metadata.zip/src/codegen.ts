process.stdout.write('\x1Bc')
import dotenv from 'dotenv'
dotenv.config({ path: '../../.env' })
dotenv.config({ path: './.env' })
import axios from 'axios'
import { getAbsFilePath } from 'noodl'
import { generate } from '@graphql-codegen/cli'

const graphqlEndpoint = 'https://ecos-noodl.hasura.app/v1/graphql'

export function generateFiles() {
  return generate({
    schema: getAbsFilePath('./src/documents/**/*.graphql'),
    hooks: {},
    generates: {
      [getAbsFilePath('./introspection.json')]: {
        plugins: ['introspection'],
      },
      [getAbsFilePath('./schema.graphql')]: {
        plugins: ['schema-ast'],
      },
      [getAbsFilePath('./src/types/graphqlTypes.ts')]: {
        plugins: ['typescript', 'typescript-operations'],
      },
    },
    overwrite: true,
    // watch: true,
  })
}

generateFiles()
  .then(async (generatedFiles) => {
    console.log(generatedFiles)
    const resp = await axios.post(
      graphqlEndpoint,
      {
        query: `{
        actions {
          actionType
        }
      }`,
      },
      {
        headers: {
          Authorization: `pat ${process.env.ADMIN_SECRET}`,
          'x-hasura-admin-secret': process.env.HASURA_GRAPHQL_ADMIN_SECRET,
        },
      },
    )
    console.log(resp.data.data.actions)
  })
  .catch((error) => {
    if (error instanceof Error) throw error
    throw new Error(String(error))
  })
