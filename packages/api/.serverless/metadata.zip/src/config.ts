export const graphqlEndpoint = 'https://ecos-noodl.hasura.app/v1/graphql'
