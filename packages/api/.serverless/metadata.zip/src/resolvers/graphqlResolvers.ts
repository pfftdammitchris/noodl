import * as u from '@jsmanifest/utils'
import * as nt from 'noodl-types'
import { GraphQLFieldResolver } from 'graphql'

export const Query: Record<string, GraphQLFieldResolver<any, any>> = {
  actionTypes(source, args, context) {
    console.log(`[actionTypes] args`, { source, args, context })
    return 'hello'
  },
}

export const Mutation = {
  //
}
