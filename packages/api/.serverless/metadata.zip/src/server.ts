import { ApolloServer, gql } from 'apollo-server-lambda'
import { loadFilesSync } from '@graphql-tools/load-files'
import express from 'express'
import { Query, Mutation } from './resolvers/graphqlResolvers'

const typeDefs = loadFilesSync('./schema.graphql')
const resolvers = {
  Query,
  Mutation,
}

const server = new ApolloServer({
  context({ event, context, express }) {
    return {
      headers: event.headers,
      functionName: context.functionName,
      event,
      context,
      expressRequest: express.req,
    }
  },
  debug: true,
  introspection: true,
  plugins: [],
  resolvers,
  typeDefs,
})

exports.handler = server.createHandler({
  expressAppFromMiddleware(middleware) {
    const app = express()
    app.use(middleware)
    return app
  },
})
