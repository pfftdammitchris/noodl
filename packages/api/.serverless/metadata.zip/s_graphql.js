
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pfftdammitchris',
  applicationName: 'noodl-api',
  appUid: 'YFX5LZVqZj25C8fwlL',
  orgUid: '32cdd517-dc92-4ad4-89c0-a2dbb954cfef',
  deploymentUid: 'cf944a15-6495-49e9-86b0-9d441bf2741a',
  serviceName: 'metadata',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'metadata-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./src/server.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}